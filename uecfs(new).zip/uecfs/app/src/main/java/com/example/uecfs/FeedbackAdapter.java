package com.example.uecfs;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class FeedbackAdapter extends RecyclerView.Adapter<FeedbackAdapter.FeedbackViewHolder> {

    private Context context;
    private List<Feedback> feedbackList;

    public FeedbackAdapter(Context context, List<Feedback> feedbackList) {
        this.context = context;
        this.feedbackList = feedbackList;
    }

    @NonNull
    @Override
    public FeedbackViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_feedback, parent, false);
        return new FeedbackViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FeedbackViewHolder holder, int position) {
        Feedback feedback = feedbackList.get(position);
        holder.bind(feedback);
    }

    @Override
    public int getItemCount() {
        return feedbackList.size();
    }

    public static class FeedbackViewHolder extends RecyclerView.ViewHolder {
        TextView tvLocationDescription;
        TextView tvCleanlinessRating;
        TextView tvCleanlinessProgress;

        public FeedbackViewHolder(@NonNull View itemView) {
            super(itemView);
            tvLocationDescription = itemView.findViewById(R.id.tvLocationDescription);
            tvCleanlinessRating = itemView.findViewById(R.id.tvCleanlinessRating);
            tvCleanlinessProgress = itemView.findViewById(R.id.tvCleanlinessProgress);
        }

        public void bind(Feedback feedback) {
            tvLocationDescription.setText("Location Description: " + feedback.getLocationDescription());
            tvCleanlinessRating.setText("Cleanliness Rating: " + feedback.getCleanlinessRating());
            tvCleanlinessProgress.setText("Cleanliness Progress: " + feedback.getCleanlinessProgress());
        }
    }
}
