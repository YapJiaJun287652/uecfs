package com.example.uecfs;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class HomePageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
    }

    public void openLogOutActivity(View view) {
        Intent intent = new Intent(HomePageActivity.this, LogOutActivity.class);
        startActivity(intent);

    }

    public void openProfileActivity(View view) {
        Intent intent = new Intent(HomePageActivity.this, ProfileActivity.class);
        startActivity(intent);

    }

    public void openNotificationActivity(View view) {
        Intent intent = new Intent(HomePageActivity.this, NotificationActivity.class);
        startActivity(intent);
    }

    public void openGiveFeedbackActivity(View view) {
        Intent intent = new Intent(HomePageActivity.this, GiveFeedbackActivity.class);
        startActivity(intent);
    }

    public void openContactHotlineActivity(View view) {
        Intent intent = new Intent(HomePageActivity.this, ContactHotlineActivity.class);
        startActivity(intent);
    }

    public void openViewFeedbackActivity(View view) {
        Intent intent = new Intent(HomePageActivity.this, ViewFeedbackActivity.class);
        startActivity(intent);
    }

    public void openHotspotActivity(View view) {
        Intent intent = new Intent(HomePageActivity.this, HotspotActivity.class);
        startActivity(intent);
    }

}